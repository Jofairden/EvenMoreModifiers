using Loot.UI;
using Terraria;

namespace Loot.Core.Cubes
{
	public class CubeOfSealing : MagicalCube
	{
		protected override string CubeName => "Cube of Sealing";
		protected override CubeTier Tier => CubeTier.TierI;

		protected override void SafeStaticDefaults()
		{
			Tooltip.SetDefault("Press left control and right click to open cube UI" +
			                   "\nAllows sealing an item's modifiers" +
			                   "\nSealing modifiers means they cannot be changed" +
			                   "\nCube is consumed upon use");
		}

		protected override void SafeDefaults()
		{
			item.value = Item.buyPrice(copper: 50);
		}

		public override void RightClick(Player player)
		{
//			Loot.Instance.cubeRerollUI._cubePanel.item.SetDefaults(item.type);
//			Loot.Instance.cubeRerollUI._cubePanel.RecalculateStack();
			
			if (!Loot.Instance.cubeSealUI.Visible || Loot.Instance.cubeSealUI.Visible && Loot.Instance.cubeSealUI._itemPanel.item.IsAir)
			{
				Loot.Instance.cubeSealUI.ToggleUI();
			}
			
			// Must be after recalc, otherwise it affects the calculated stack
			item.stack++;
		}
	}
}
﻿namespace Loot
{
	//class ItemHackForceWeapon : ModPrefix
	//{
	//	public override PrefixCategory Category => PrefixCategory.Custom;
	//	public override void SetDefaults()
	//	{
	//		DisplayName.SetDefault("");
	//	}
	//}

	//class ItemHackForceAccessory : ModPrefix
	//{
	//	public override PrefixCategory Category => PrefixCategory.Custom;
	//	public override void SetDefaults()
	//	{
	//		DisplayName.SetDefault("");
	//	}
	//}

	//class ItemHackForceSimulate : ModPrefix
	//{
	//	public override PrefixCategory Category => PrefixCategory.Custom;
	//	public override void SetDefaults()
	//	{
	//		DisplayName.SetDefault("");
	//	}
	//}
}

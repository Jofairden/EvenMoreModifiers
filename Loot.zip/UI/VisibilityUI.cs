using Terraria.UI;

namespace Loot.UI
{
	/// <summary>
	/// A UIState which primarily goal is to provide easy visibility toggling
	/// </summary>
	public abstract class VisibilityUI : UIState
	{
		public bool Visible;

		public virtual void ToggleUI()
		{
			Visible = !Visible;
		}
	}
}
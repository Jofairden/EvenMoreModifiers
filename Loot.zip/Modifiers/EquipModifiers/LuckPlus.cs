﻿using Loot.Core;
using Microsoft.Xna.Framework;
using Terraria;

namespace Loot.Modifiers.EquipModifiers
{
	// todo Be in effect
	public class LuckEffect : ModifierEffect
	{
		public float Luck;

		public override void ResetEffects(ModifierPlayer player)
		{
			Luck = 0f;
		}
	}
	
	[UsesEffect(typeof(LuckEffect))]
	public class LuckPlus : EquipModifier
	{
		public override ModifierTooltipLine[] TooltipLines => new[]
		{
			new ModifierTooltipLine { Text = $"+{Properties.RoundedPower} luck [WIP]", Color =  Color.LimeGreen},
		};

		public override ModifierProperties GetModifierProperties(Item item)
		{
			return base.GetModifierProperties(item).Set(maxMagnitude: 10f);
		}
		
		public override void UpdateEquip(Item item, Player player)
		{
			ModifierPlayer.Player(player).GetEffect<LuckEffect>().Luck += (int)Properties.RoundedPower;
		}
	}
}
